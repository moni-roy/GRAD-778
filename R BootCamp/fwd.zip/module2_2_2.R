sum <- function(x_vector) {
  vector_sum <- x_vector + 2
  return(vector_sum)
}
foo <- c(2, 4, 6, 8)
sum(foo)